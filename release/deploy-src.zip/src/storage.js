'use strict';
/* =========================================================
   storage.js — слой хранения метаданных на SQLite (node:sqlite).
   При первом запуске переносит пользователей/проекты/журнал/телеметрию
   из JSON в БД, оставляя JSON как архив (и делая резервную копию).
   ========================================================= */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { DatabaseSync } = require('node:sqlite');

let db = null;
let dataDir = null;

const SCHEMA_VERSION = 2;

function nowIso() { return new Date().toISOString(); }

function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch {} throw e; }
}

function init({ dir }) {
  if (db) return db;
  dataDir = path.resolve(dir);
  fs.mkdirSync(dataDir, { recursive: true });
  const file = path.join(dataDir, 'dossier.db');
  db = new DatabaseSync(file);
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA synchronous = NORMAL;
    PRAGMA busy_timeout = 5000;
    CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, payload TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS changes (
      id TEXT PRIMARY KEY, ts TEXT NOT NULL, action TEXT, actor TEXT,
      file TEXT, project_id TEXT, payload TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_changes_ts ON changes(ts DESC);
    CREATE INDEX IF NOT EXISTS idx_changes_file ON changes(file);
    CREATE INDEX IF NOT EXISTS idx_changes_project ON changes(project_id);
    CREATE TABLE IF NOT EXISTS telemetry (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL, ts TEXT NOT NULL, payload TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_telemetry_user_ts ON telemetry(username, ts DESC);
    CREATE TABLE IF NOT EXISTS sessions (
      sid TEXT PRIMARY KEY, sess TEXT NOT NULL, expires INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires);
    CREATE TABLE IF NOT EXISTS notifications (
      id TEXT PRIMARY KEY, username TEXT NOT NULL, type TEXT NOT NULL,
      created_at TEXT NOT NULL, read_at TEXT, payload TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS documents (
      name TEXT PRIMARY KEY, payload TEXT NOT NULL, updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(username, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(username, read_at);
  `);
  db.prepare('INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run('schema_version', String(SCHEMA_VERSION));
  db.prepare('INSERT OR IGNORE INTO meta (key, value) VALUES (?, ?)').run('notifications_ready', '1');
  migrateFromJson();
  migrateDocsFromJson();
  return db;
}

/* ---------- Миграция JSON → SQLite ---------- */
function readJsonSafe(file, fallback) {
  if (!fs.existsSync(file)) return fallback;
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) {
    const bak = file + '.bak';
    if (fs.existsSync(bak)) {
      try { return JSON.parse(fs.readFileSync(bak, 'utf8')); } catch {}
    }
    throw new Error('Не удалось прочитать ' + path.basename(file) + ' для миграции: ' + e.message);
  }
}

function metaGet(key) {
  const row = db.prepare('SELECT value FROM meta WHERE key = ?').get(key);
  return row ? row.value : null;
}
function metaSet(key, value) {
  db.prepare('INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value')
    .run(key, String(value));
}

function migrateFromJson() {
  if (metaGet('json_migrated') === '1') return;
  const usersFile = path.join(dataDir, 'users.json');
  const projectsFile = path.join(dataDir, 'projects.json');
  const changesFile = path.join(dataDir, 'changes.json');
  const telemetryDir = path.join(dataDir, 'telemetry');
  const hasAny = fs.existsSync(usersFile) || fs.existsSync(projectsFile) ||
    fs.existsSync(changesFile) || fs.existsSync(telemetryDir);
  if (!hasAny) { metaSet('json_migrated', '1'); return; }

  // Резервная копия перед миграцией — JSON не удаляем, он остаётся архивом.
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = path.join(dataDir, 'backup-pre-sqlite-' + stamp);
  fs.mkdirSync(backupDir, { recursive: true });
  const copyIfExists = (src, dstName) => {
    try { if (fs.existsSync(src)) fs.copyFileSync(src, path.join(backupDir, dstName)); } catch {}
  };
  copyIfExists(usersFile, 'users.json');
  copyIfExists(projectsFile, 'projects.json');
  copyIfExists(changesFile, 'changes.json');
  fs.writeFileSync(path.join(backupDir, 'README.txt'),
    'Резервная копия JSON перед миграцией в SQLite (' + new Date().toISOString() + ').\n' +
    'Данные перенесены в dossier.db; JSON оставлены как архив.\n', 'utf8');

  const users = readJsonSafe(usersFile, { users: [] }).users || [];
  const projects = readJsonSafe(projectsFile, { projects: [] }).projects || [];
  const changes = readJsonSafe(changesFile, { entries: [] }).entries || [];
  let telemetryEvents = 0;

  tx(() => {
    for (const u of users) {
      if (!u || !u.id || !u.username) continue;
      db.prepare('INSERT OR IGNORE INTO users (id, username, payload) VALUES (?, ?, ?)')
        .run(u.id, u.username, JSON.stringify(u));
    }
    for (const p of projects) {
      if (!p || !p.id) continue;
      db.prepare('INSERT OR IGNORE INTO projects (id, payload) VALUES (?, ?)')
        .run(p.id, JSON.stringify(p));
    }
    for (const e of changes) {
      if (!e || !e.id) continue;
      db.prepare(`INSERT OR IGNORE INTO changes (id, ts, action, actor, file, project_id, payload)
                  VALUES (?, ?, ?, ?, ?, ?, ?)`)
        .run(e.id, e.timestamp || nowIso(), e.action || null, e.user || null,
             e.file || null, e.projectId || null, JSON.stringify(e));
    }
    if (fs.existsSync(telemetryDir)) {
      for (const f of fs.readdirSync(telemetryDir)) {
        if (!f.endsWith('.json')) continue;
        try {
          const d = JSON.parse(fs.readFileSync(path.join(telemetryDir, f), 'utf8'));
          const username = d.username || f.replace(/\.json$/, '');
          for (const ev of (d.events || [])) {
            db.prepare('INSERT INTO telemetry (username, ts, payload) VALUES (?, ?, ?)')
              .run(username, ev.ts || nowIso(), JSON.stringify(ev));
            telemetryEvents++;
          }
        } catch {}
      }
    }
  });
  trimChanges();
  for (const row of listTelemetryUsers()) trimTelemetry(row.username);
  metaSet('json_migrated', '1');
  metaSet('json_migrated_at', nowIso());
  console.log(`[storage] JSON → SQLite: пользователей ${users.length}, проектов ${projects.length}, ` +
    `записей журнала ${changes.length}, событий телеметрии ${telemetryEvents}. ` +
    `Резервная копия: ${backupDir}`);
}

/* ---------- Документы (JSON-хранилища, перенесённые в SQLite) ---------- */
// name -> файл в data/ (для миграции; сами файлы остаются архивом)
const DOC_FILES = {
  settings: 'settings.json',
  invites: 'invites.json',
  punishments: 'punishments.json',
  requests: 'requests.json',
  reports: 'reports.json',
  tickets: 'tickets.json',
  chat: 'chat.json',
  'project-chats': 'project-chats.json',
  attachments: 'attachments.json',
  ads: 'ads.json',
  subscriptions: 'subscriptions.json',
  shares: 'shares.json',
  trash: 'trash.json',
  'project-meta': 'project-meta.json',
  'darcus-chats': 'darcus-chats.json',
};

function docExists(name) {
  return !!db.prepare('SELECT 1 FROM documents WHERE name = ?').get(name);
}

function migrateDocsFromJson() {
  if (metaGet('docs_migrated') === '1') return;
  const existing = Object.entries(DOC_FILES)
    .filter(([, file]) => fs.existsSync(path.join(dataDir, file)));
  if (existing.length) {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupDir = path.join(dataDir, 'backup-pre-docs-' + stamp);
    fs.mkdirSync(backupDir, { recursive: true });
    for (const [, file] of existing) {
      try { fs.copyFileSync(path.join(dataDir, file), path.join(backupDir, file)); } catch {}
    }
  }
  let migrated = 0;
  tx(() => {
    const stmt = db.prepare('INSERT OR IGNORE INTO documents (name, payload, updated_at) VALUES (?, ?, ?)');
    for (const [name, file] of Object.entries(DOC_FILES)) {
      if (docExists(name)) continue;
      const full = path.join(dataDir, file);
      if (!fs.existsSync(full)) continue;
      try {
        const data = readJsonSafe(full, undefined);
        if (data === undefined) continue;
        stmt.run(name, JSON.stringify(data), nowIso());
        migrated++;
      } catch (e) { console.warn("[storage] doc migrate failed: " + file + ": " + e.message); }
    }
  });
  metaSet('docs_migrated', '1');
  metaSet('docs_migrated_at', nowIso());
  if (migrated) console.log('[storage] JSON-документы → SQLite: ' + migrated + ' шт., резервная копия в data/backup-pre-docs-*');
}

function getDoc(name, fallback) {
  const row = db.prepare('SELECT payload FROM documents WHERE name = ?').get(name);
  if (!row) return fallback;
  try { return JSON.parse(row.payload); } catch { return fallback; }
}

function setDoc(name, data) {
  const json = JSON.stringify(data);
  db.prepare('INSERT INTO documents (name, payload, updated_at) VALUES (?, ?, ?) ' +
    'ON CONFLICT(name) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at')
    .run(name, json, nowIso());
  return data;
}

function deleteDoc(name) {
  db.prepare('DELETE FROM documents WHERE name = ?').run(name);
}

/* ---------- Пользователи ---------- */
function getUsers() {
  return db.prepare('SELECT payload FROM users ORDER BY rowid').all().map(r => JSON.parse(r.payload));
}
function replaceUsers(users) {
  tx(() => {
    db.exec('DELETE FROM users');
    const stmt = db.prepare('INSERT INTO users (id, username, payload) VALUES (?, ?, ?)');
    for (const u of users) stmt.run(u.id, u.username, JSON.stringify(u));
  });
}
function findUserByUsername(username) {
  const row = db.prepare('SELECT payload FROM users WHERE username = ?').get(username);
  return row ? JSON.parse(row.payload) : null;
}
function findUserById(id) {
  const row = db.prepare('SELECT payload FROM users WHERE id = ?').get(id);
  return row ? JSON.parse(row.payload) : null;
}
function countUsers() {
  return db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
}

/* ---------- Проекты ---------- */
function getProjects() {
  return db.prepare('SELECT payload FROM projects ORDER BY rowid').all().map(r => JSON.parse(r.payload));
}
function replaceProjects(projects) {
  tx(() => {
    db.exec('DELETE FROM projects');
    const stmt = db.prepare('INSERT INTO projects (id, payload) VALUES (?, ?)');
    for (const p of projects) stmt.run(p.id, JSON.stringify(p));
  });
}

/* ---------- Журнал изменений ---------- */
function appendChange(entry) {
  const e = { id: entry.id || crypto.randomUUID(), timestamp: entry.timestamp || nowIso(), ...entry };
  db.prepare(`INSERT INTO changes (id, ts, action, actor, file, project_id, payload)
              VALUES (?, ?, ?, ?, ?, ?, ?)`)
    .run(e.id, e.timestamp, e.action || null, e.user || null,
         e.file || null, e.projectId || null, JSON.stringify(e));
  trimChanges();
  return e;
}
function trimChanges() {
  const max = 5000;
  const count = db.prepare('SELECT COUNT(*) AS n FROM changes').get().n;
  if (count <= max) return;
  db.prepare(`DELETE FROM changes WHERE id IN (
    SELECT id FROM changes ORDER BY ts ASC LIMIT ?)`).run(count - max);
}
function getChange(id) {
  const row = db.prepare('SELECT payload FROM changes WHERE id = ?').get(id);
  return row ? JSON.parse(row.payload) : null;
}
function updateChange(id, patch) {
  const cur = getChange(id);
  if (!cur) return null;
  const next = { ...cur, ...patch };
  db.prepare('UPDATE changes SET payload = ?, action = ?, file = ?, project_id = ? WHERE id = ?')
    .run(JSON.stringify(next), next.action || null, next.file || null, next.projectId || null, id);
  return next;
}
function queryChanges({ file, projectId, days, limit = 500, offset = 0, full = false } = {}) {
  const where = [];
  const params = [];
  if (file) { where.push('file = ?'); params.push(file); }
  if (projectId) { where.push('project_id = ?'); params.push(projectId); }
  if (days) {
    const since = new Date(Date.now() - days * 86400 * 1000).toISOString();
    where.push('ts >= ?'); params.push(since);
  }
  const whereSql = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const total = db.prepare('SELECT COUNT(*) AS n FROM changes ' + whereSql).get(...params).n;
  const rows = db.prepare('SELECT payload FROM changes ' + whereSql + ' ORDER BY ts DESC LIMIT ? OFFSET ?')
    .all(...params, limit, offset);
  let entries = rows.map(r => JSON.parse(r.payload));
  if (!full) entries = entries.map(({ before, after, ...rest }) => rest);
  return { entries, total };
}
function listAllChanges() {
  return db.prepare('SELECT payload FROM changes ORDER BY ts DESC').all().map(r => JSON.parse(r.payload));
}

/* ---------- Телеметрия ---------- */
function appendTelemetryBatch(username, events) {
  if (!username || !events.length) return;
  tx(() => {
    const stmt = db.prepare('INSERT INTO telemetry (username, ts, payload) VALUES (?, ?, ?)');
    for (const ev of events) stmt.run(username, ev.ts || nowIso(), JSON.stringify(ev));
  });
  trimTelemetry(username);
}
function trimTelemetry(username) {
  const max = 2000;
  const count = db.prepare('SELECT COUNT(*) AS n FROM telemetry WHERE username = ?').get(username).n;
  if (count <= max) return;
  db.prepare(`DELETE FROM telemetry WHERE id IN (
    SELECT id FROM telemetry WHERE username = ? ORDER BY ts ASC LIMIT ?)`).run(username, count - max);
}
function listTelemetryUsers() {
  return db.prepare(`SELECT username, COUNT(*) AS events, MAX(ts) AS lastSeen
                     FROM telemetry GROUP BY username ORDER BY lastSeen DESC`).all();
}
function getTelemetry(username, limit = 5000) {
  const rows = db.prepare('SELECT payload FROM telemetry WHERE username = ? ORDER BY ts DESC LIMIT ?')
    .all(username, limit);
  const events = rows.map(r => JSON.parse(r.payload));
  const first = db.prepare('SELECT ts FROM telemetry WHERE username = ? ORDER BY ts ASC LIMIT 1').get(username);
  return {
    username,
    events,
    firstSeen: first ? first.ts : null,
    lastSeen: events[0]?.ts || null,
  };
}
function clearTelemetry(username) {
  db.prepare('DELETE FROM telemetry WHERE username = ?').run(username);
}

/* ---------- Сессии (express-session store) ---------- */
function createSessionStore(expressSession) {
  class SqliteSessionStore extends expressSession.Store {
    constructor() {
      super();
      this.cleanupTimer = setInterval(() => this.clearExpired(), 15 * 60 * 1000);
      if (this.cleanupTimer.unref) this.cleanupTimer.unref();
    }
    get(sid, cb) {
      try {
        const row = db.prepare('SELECT sess, expires FROM sessions WHERE sid = ?').get(sid);
        if (!row) return cb(null, null);
        if (row.expires <= Date.now()) { this.destroy(sid, () => {}); return cb(null, null); }
        cb(null, JSON.parse(row.sess));
      } catch (e) { cb(e); }
    }
    set(sid, sess, cb) {
      try {
        const expires = sess && sess.cookie && sess.cookie.expires
          ? new Date(sess.cookie.expires).getTime()
          : Date.now() + 7 * 86400 * 1000;
        db.prepare(`INSERT INTO sessions (sid, sess, expires) VALUES (?, ?, ?)
                    ON CONFLICT(sid) DO UPDATE SET sess = excluded.sess, expires = excluded.expires`)
          .run(sid, JSON.stringify(sess), expires);
        cb && cb(null);
      } catch (e) { cb && cb(e); }
    }
    touch(sid, sess, cb) {
      try {
        const expires = sess && sess.cookie && sess.cookie.expires
          ? new Date(sess.cookie.expires).getTime()
          : Date.now() + 7 * 86400 * 1000;
        db.prepare('UPDATE sessions SET expires = ? WHERE sid = ?').run(expires, sid);
        cb && cb(null);
      } catch (e) { cb && cb(e); }
    }
    destroy(sid, cb) {
      try { db.prepare('DELETE FROM sessions WHERE sid = ?').run(sid); cb && cb(null); }
      catch (e) { cb && cb(e); }
    }
    clearExpired() {
      try { db.prepare('DELETE FROM sessions WHERE expires <= ?').run(Date.now()); } catch {}
    }
    length(cb) {
      try { cb(null, db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n); } catch (e) { cb(e); }
    }
  }
  return new SqliteSessionStore();
}

/* ---------- Уведомления ---------- */
function createNotification({ username, type, title, body = '', link = null, projectId = null }) {
  if (!username || !type) return null;
  const item = {
    id: crypto.randomUUID(),
    username,
    type: String(type).slice(0, 40),
    title: String(title || '').slice(0, 200),
    body: String(body || '').slice(0, 500),
    link: link ? String(link).slice(0, 300) : null,
    projectId: projectId || null,
    createdAt: nowIso(),
    readAt: null,
  };
  db.prepare(`INSERT INTO notifications (id, username, type, created_at, read_at, payload)
              VALUES (?, ?, ?, ?, NULL, ?)`)
    .run(item.id, item.username, item.type, item.createdAt, JSON.stringify(item));
  // Держим не больше 200 уведомлений на пользователя.
  const count = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE username = ?').get(username).n;
  if (count > 200) {
    db.prepare(`DELETE FROM notifications WHERE id IN (
      SELECT id FROM notifications WHERE username = ? ORDER BY created_at ASC LIMIT ?)`)
      .run(username, count - 200);
  }
  return item;
}

function listNotifications(username, { limit = 30, unreadOnly = false } = {}) {
  const lim = Math.min(Math.max(parseInt(limit, 10) || 30, 1), 100);
  const where = unreadOnly ? 'username = ? AND read_at IS NULL' : 'username = ?';
  const rows = db.prepare(`SELECT payload FROM notifications WHERE ${where}
                           ORDER BY created_at DESC LIMIT ?`).all(username, lim);
  const unread = db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE username = ? AND read_at IS NULL')
    .get(username).n;
  return { items: rows.map(r => JSON.parse(r.payload)), unread };
}

function markNotificationRead(username, id) {
  const row = db.prepare('SELECT payload FROM notifications WHERE id = ? AND username = ?').get(id, username);
  if (!row) return null;
  const item = JSON.parse(row.payload);
  if (!item.readAt) {
    item.readAt = nowIso();
    db.prepare('UPDATE notifications SET read_at = ?, payload = ? WHERE id = ?')
      .run(item.readAt, JSON.stringify(item), id);
  }
  return item;
}

function markAllNotificationsRead(username) {
  const now = nowIso();
  const rows = db.prepare('SELECT payload FROM notifications WHERE username = ? AND read_at IS NULL').all(username);
  const stmt = db.prepare('UPDATE notifications SET read_at = ?, payload = ? WHERE id = ?');
  tx(() => {
    for (const r of rows) {
      const item = JSON.parse(r.payload);
      item.readAt = now;
      stmt.run(now, JSON.stringify(item), item.id);
    }
  });
  return rows.length;
}

function clearNotifications(username) {
  db.prepare('DELETE FROM notifications WHERE username = ?').run(username);
}

/* ---------- Экспорт/импорт метаданных ---------- */
const SNAPSHOT_APP = 'darkarmy-dossier';
const SNAPSHOT_VERSION = 1;

function exportSnapshot() {
  const documents = {};
  for (const row of db.prepare('SELECT name, payload FROM documents').all()) {
    try { documents[row.name] = JSON.parse(row.payload); } catch {}
  }
  return {
    app: SNAPSHOT_APP,
    version: SNAPSHOT_VERSION,
    exportedAt: nowIso(),
    users: getUsers(),
    projects: getProjects(),
    documents,
  };
}

function importSnapshot(snapshot, { mode = 'replace' } = {}) {
  if (!snapshot || typeof snapshot !== 'object')
    throw new Error('Пустой снимок данных');
  if (snapshot.app !== SNAPSHOT_APP)
    throw new Error('Неверный формат файла (ожидается экспорт DarkArmy Dossier)');
  if (snapshot.version !== SNAPSHOT_VERSION)
    throw new Error('Неподдерживаемая версия снимка: ' + snapshot.version);
  const users = Array.isArray(snapshot.users) ? snapshot.users : [];
  const projects = Array.isArray(snapshot.projects) ? snapshot.projects : [];
  const documents = (snapshot.documents && typeof snapshot.documents === 'object') ? snapshot.documents : {};
  if (!users.length) throw new Error('В снимке нет пользователей');
  if (!users.some(u => u && u.role === 'admin')) throw new Error('В снимке нет администратора');
  for (const u of users) {
    if (!u || typeof u.id !== 'string' || typeof u.username !== 'string')
      throw new Error('Некорректная запись пользователя');
  }
  for (const p of projects) {
    if (!p || typeof p.id !== 'string') throw new Error('Некорректная запись проекта');
  }
  const replace = mode === 'replace';
  tx(() => {
    if (replace) {
      db.exec('DELETE FROM users');
      db.exec('DELETE FROM projects');
      db.exec('DELETE FROM documents');
    }
    const uStmt = db.prepare('INSERT OR REPLACE INTO users (id, username, payload) VALUES (?, ?, ?)');
    for (const u of users) uStmt.run(u.id, u.username, JSON.stringify(u));
    const pStmt = db.prepare('INSERT OR REPLACE INTO projects (id, payload) VALUES (?, ?)');
    for (const p of projects) pStmt.run(p.id, JSON.stringify(p));
    const dStmt = db.prepare(`INSERT INTO documents (name, payload, updated_at) VALUES (?, ?, ?)
                              ON CONFLICT(name) DO UPDATE SET payload = excluded.payload, updated_at = excluded.updated_at`);
    for (const [name, value] of Object.entries(documents)) dStmt.run(name, JSON.stringify(value), nowIso());
  });
  return {
    mode: replace ? 'replace' : 'merge',
    users: users.length,
    projects: projects.length,
    documents: Object.keys(documents).length,
  };
}

/* ---------- Диагностика ---------- */
function stats() {
  const file = path.join(dataDir, 'dossier.db');
  let logicalSize = 0;
  try {
    // В WAL-режиме файл БД на диске может быть маленьким, а данные лежать в -wal.
    // Логический размер (page_count * page_size) отражает реальный объём данных.
    const pageCount = db.prepare('PRAGMA page_count').get();
    const pageSize = db.prepare('PRAGMA page_size').get();
    logicalSize = Number(pageCount.page_count || 0) * Number(pageSize.page_size || 0);
  } catch {}
  return {
    dbFile: file,
    sizeBytes: logicalSize || (fs.existsSync(file) ? fs.statSync(file).size : 0),
    users: countUsers(),
    projects: db.prepare('SELECT COUNT(*) AS n FROM projects').get().n,
    changes: db.prepare('SELECT COUNT(*) AS n FROM changes').get().n,
    telemetry: db.prepare('SELECT COUNT(*) AS n FROM telemetry').get().n,
    notifications: db.prepare('SELECT COUNT(*) AS n FROM notifications').get().n,
    documents: db.prepare('SELECT COUNT(*) AS n FROM documents').get().n,
    sessions: db.prepare('SELECT COUNT(*) AS n FROM sessions').get().n,
    schemaVersion: Number(metaGet('schema_version') || 0),
    jsonMigratedAt: metaGet('json_migrated_at'),
  };
}

function close() {
  if (db) { try { db.close(); } catch {} db = null; }
}

module.exports = {
  init, close, stats,
  getUsers, replaceUsers, findUserByUsername, findUserById, countUsers,
  getProjects, replaceProjects,
  getDoc, setDoc, deleteDoc,
  appendChange, getChange, updateChange, queryChanges, listAllChanges,
  appendTelemetryBatch, listTelemetryUsers, getTelemetry, clearTelemetry,
  createNotification, listNotifications, markNotificationRead, markAllNotificationsRead, clearNotifications,
  exportSnapshot, importSnapshot,
  createSessionStore,
};
