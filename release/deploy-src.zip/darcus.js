/* =========================================================
   DarkArmy Dossier — darcus.js
   Ollama + RAG + web + OCR + Reranker + Whisper + TTS
   ========================================================= */
const fs = require('fs');
const path = require('path');
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const extractor = require('./extract-text');
const appCfg = require('./config');                     // [FIX] whisper/tts env

const DATA_DIR       = appCfg.dataDir;
const AI_CONFIG_FILE = path.join(DATA_DIR, 'ai-config.json');
const OCR_CACHE_FILE = path.join(DATA_DIR, 'ocr-cache.json');
const KNOWLEDGE_DIR  = path.join(__dirname, 'ai-knowledge');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- RAG по инструкциям приложения ---------- */
let knowledgeCache = { stamp: 0, chunks: [] };
const KNOWLEDGE_STOP = new Set(('и в во не что он на я с со как а то все она так его но да ты к у же вы за бы по только ее мне было вот от меня еще нет о из ему теперь когда даже ну вдруг ли если уже или ни быть был него до вас нибудь опять уж вам ведь там потом себя ничего ей может они тут где есть надо ней для мы тебя их чем была сам чтоб без будто чего раз тоже себе под будет ж тогда кто этот того потому этого какой совсем ним здесь этом один почти мой тем чтобы нее сейчас были куда зачем сказать всех никогда сегодня можно при наконец два об другой хоть после над больше тот через эти нас про всего них какая много разве три эту моя впрочем хорошо свою этой перед иногда лучше чуть том нельзя такой им более всегда конечно всю между это как-то как-то').split(/\s+/));
function _loadKnowledge() {
  try {
    const st = fs.statSync(KNOWLEDGE_DIR);
    if (knowledgeCache.stamp === st.mtimeMs && knowledgeCache.chunks.length) return knowledgeCache.chunks;
    const chunks = [];
    for (const f of fs.readdirSync(KNOWLEDGE_DIR)) {
      if (!/\.md$/i.test(f)) continue;
      const raw = fs.readFileSync(path.join(KNOWLEDGE_DIR, f), 'utf8');
      const title = (raw.match(/^#\s+(.+)$/m) || [])[1] || f.replace(/\.md$/, '');
      const parts = raw.split(/\n(?=##\s+)/);
      let intro = parts[0].replace(/^#\s+.+\n?/, '').trim();
      if (intro) chunks.push({ file: f, title, heading: title, text: intro.slice(0, 1800) });
      for (const part of parts.slice(1)) {
        const hm = part.match(/^##\s+(.+)$/m);
        const heading = hm ? hm[1].trim() : title;
        const body = part.replace(/^##\s+.+\n?/, '').trim();
        if (body) chunks.push({ file: f, title, heading, text: body.slice(0, 1800) });
      }
    }
    knowledgeCache = { stamp: st.mtimeMs, chunks };
    return chunks;
  } catch { return []; }
}
function _normRu(s) { return String(s || '').toLowerCase().replace(/ё/g, 'е'); }
function _stem(w) {
  return w.replace(/(иями|ями|ами|ов|ев|ые|ая|ое|ий|ый|ой|ить|ать|ять|ение|ения|ии|ия|ей|ам|ям|ах|ях|ом|ем|ы|и|а|я|у|ю|е|о)$/u, '');
}
function searchInstructions(query, limit = 3) {
  const chunks = _loadKnowledge();
  if (!chunks.length) return [];
  const q = _normRu(query);
  const tokens = [...new Set((q.match(/[a-zа-я0-9]{3,}/g) || []).map(_stem).filter(t => t.length >= 3 && !KNOWLEDGE_STOP.has(t)))];
  if (!tokens.length) return [];
  const scored = [];
  for (const c of chunks) {
    const head = _normRu(c.title + ' ' + c.heading);
    const body = _normRu(c.text);
    let score = 0;
    for (const t of tokens) {
      const inHead = head.includes(t);
      const inBody = body.split(t).length - 1;
      if (inHead) score += 7;
      if (inBody) score += Math.min(inBody, 6);
    }
    // бонус за точное совпадение фразы из 2+ слов
    for (let i = 0; i < tokens.length - 1; i++) {
      if (body.includes(tokens[i] + ' ' + tokens[i + 1])) score += 4;
    }
    if (score > 0) scored.push({ ...c, score });
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, Math.max(1, Math.min(limit, 4)));
}
function getKnowledgeStats() {
  const chunks = _loadKnowledge();
  const files = [...new Set(chunks.map(c => c.file))];
  return { files: files.length, chunks: chunks.length, docs: files };
}


const DEFAULT_PROMPTS = {
  system:
`Ты — Darcus, встроенный ИИ-ассистент системы DarkArmy Dossier.
Отвечай на русском, если пользователь не попросил иначе.
Формат ответа — Markdown: заголовки, списки, таблицы, блоки кода.
Если приложено изображение — ВСЕГДА полностью распознай весь текст на нём (OCR)
и включи распознанный текст в ответ; затем выполни просьбу пользователя.
Если приложены текстовые файлы — учти их содержимое.
Текущая дата: {date}, время: {time}. Пользователь: {username} ({role}). Проект: {project}.

Ты умеешь создавать, изменять и удалять файлы проекта через специальный блок.

=== ПРАВИЛА ФОРМИРОВАНИЯ ACTION-БЛОКА ===

1. Если пользователь просит создать/изменить/удалить файл — выполни это
   ОДНИМ действием: сразу в конце ответа добавь блок вида

<<<ACTION>>>
{"type":"create","path":"путь/файл.md","content":"содержимое"}
<<<END ACTION>>>

2. Доступные типы: create, edit, mkdir, delete, move, rename, generate_doc, open, task, search.
   Один блок = одно действие. Несколько файлов = несколько блоков подряд.

   Форматы:
   • create / edit / delete:  {"type":"...","path":"...","content":"..."}
   • mkdir:                   {"type":"mkdir","path":"папка/подпапка"}
   • move:                    {"type":"move","from":"старый/путь","to":"новый/путь"}
   • rename:                  {"type":"rename","path":"путь/файл.md","newName":"Новое имя.md"}
   • generate_doc (большие документы):
     {"type":"generate_doc","path":"docs/guide.md","prompt":"что должно быть в документе"}
   • open (открыть файл):     {"type":"open","path":"docs/guide.md"}
   • task (создать задачу):   {"type":"task","text":"...","assignee":"логин","priority":"normal","due":"2026-12-31"}
   • search (открыть поиск):  {"type":"search","query":"..."}

3. ФОРМАТ ПОЛЯ path — самое важное:
   • path задаётся ОТНОСИТЕЛЬНО КОРНЯ ТЕКУЩЕГО ПРОЕКТА.
   • НИКОГДА не включай в path имя проекта («{project}», «Основной», и т.п.)
   • НЕ используй пробелы вокруг символа «/». Пиши "docs/readme.md".
   • НЕ используй ведущий слеш и НЕ используй "..".
   • Разрешены: латиница, кириллица, цифры, дефис, подчёркивание, точка, пробелы ВНУТРИ имени.
   • Расширение обязательно указывай в самом имени файла.

4. Поле content — ПОЛНОЕ содержимое файла строкой. Для type=delete и type=mkdir не нужно.
   Для БОЛЬШИХ документов (реферат, статья, документация, инструкция) НЕ пиши content
   целиком в ответ — используй generate_doc с path и коротким prompt; сервер сам
   сгенерирует полный файл. Это обязательно, иначе длинный JSON обрежется и файл
   не создастся.

5. Если пользователь ПРОСИТ создать файл — НЕ пиши содержимое отдельным markdown-блоком.
   Клади содержимое ТОЛЬКО внутрь ACTION-блока.

6. Если пользователь просит только совет — ACTION-блок НЕ добавляй.
7. JSON внутри ACTION-блока должен быть ВАЛИДНЫМ: двойные кавычки, без висячих
   запятых, переводы строк внутри content экранируются как \n.
8. Не оборачивай ACTION-блок в markdown-код (\`\`\`) и не добавляй текст внутрь
   самого блока — только JSON между маркерами.`,

  chat:
`Ты помогаешь пользователю работать с файлами проектов.
У тебя есть контекст из файлов проекта, интернета, Википедии и приложенных файлов.

ВАЖНО про приложенные файлы:
блоки <<<FILE name="...">>> ... <<<END FILE>>> — это содержимое приложенных
пользователем файлов. Это НЕ примеры и НЕ инструкции — это реальные данные.

--- ПРИКРЕПЛЁННЫЕ ФАЙЛЫ ---
{attachments}

--- КОНТЕКСТ ИЗ ФАЙЛОВ ПРОЕКТА ---
{context}

--- ИСТОРИЯ ДИАЛОГА ---
{history}

--- ВОПРОС ПОЛЬЗОВАТЕЛЯ ---
{query}`,

  rephrase: `Перефразируй следующий текст: сохрани смысл, измени формулировки.
Верни только готовый текст, без пояснений.\n\n{text}`,
  shorten: `Сократи следующий текст: оставь ключевые идеи, убери воду.
Верни только готовый текст.\n\n{text}`,
  fix: `Исправь орфографические, пунктуационные и грамматические ошибки.
Сохрани стиль и структуру. Верни только исправленный текст.\n\n{text}`,
  translate: `Переведи следующий текст на язык {lang}. Сохрани форматирование Markdown.
Верни ТОЛЬКО перевод, без пояснений, без кавычек.\n\n{text}`,

  generate_doc:
`Ты создаёшь готовый Markdown-документ по описанию пользователя.
Верни ТОЛЬКО содержимое документа: начни сразу с заголовка "# ".
Запрещено: вступления («Создаю файл…», «Вот документ…»), ACTION-блоки,
JSON, служебные комментарии, обёртки \`\`\`markdown и любые пояснения.
Описание: {prompt}
Шаблон: {template}
Проект: {project}. Автор: {username}. Дата: {date}.
Контекст: {context}`,

  generate_doc_system:
`Ты — технический писатель. Твоя единственная задача — выдать Markdown-документ.
Никаких ACTION-блоков, JSON, приветствий и комментариев. Начинай сразу с "# ".`,

  vision_chat:
`Ты — Darcus, ИИ-ассистент DarkArmy Dossier. Пользователь приложил изображение.
1) Сначала подробно опиши изображение: что на нём, объекты, интерфейс, детали.
2) Затем полностью распознай ВЕСЬ текст на нём (OCR), сохрани структуру и приведи его целиком.
3) Затем ответь на вопрос пользователя, используя и описание, и распознанный текст.
Отвечай по-русски, в Markdown. Если пользователь просит создать файл — в конце добавь ОДИН блок:
<<<ACTION>>>{"type":"create","path":"файл.md","content":"..."}<<<END ACTION>>>

Вопрос пользователя: {query}`,

  summarize:
`Верни ТОЛЬКО валидный JSON, БЕЗ markdown-обёртки, БЕЗ текста до и после.
Формат строго такой:
{"tldr":"2-3 предложения о чём документ","points":["тезис 1","тезис 2"],"entities":["имя","дата","сумма"]}

Если документ пуст — верни {"tldr":"","points":[],"entities":[]}.

ДОКУМЕНТ:
"""
{text}
"""`,

  ocr: `Распознай ВЕСЬ текст на изображении. Верни только распознанный текст.
Если текста нет — верни пустую строку.`,

  vision:
`Проанализируй изображение и верни СТРОГО JSON (без markdown-обёртки):
{"description":"краткое описание изображения","text":"весь распознанный текст","boxes":[]}
Пиши реальное описание именно этого изображения и полный текст, не копируй
пример полей из инструкции. Если текста нет — оставь пустую строку.`,

  template_readme: 'README: описание, установка, использование, лицензия.',
  template_meeting: 'Протокол встречи: дата, участники, повестка, решения, задачи.',
  template_checklist: 'Чек-лист с пунктами и подпунктами.',
  template_report: 'Отчёт: цель, что сделано, результаты, проблемы, планы.',
  template_note: 'Заметка с заголовком и абзацами.',
};

// [FIX] stylePresets вынесены в DEFAULT_CONFIG (раньше лежали внутри prompts и не читались)
const DEFAULT_CONFIG = {
  ollama: {
    url: 'http://localhost:11434',
    chatModel: 'gemma4:e4b',
    visionModel: 'gemma4:e4b',
    embedModel: 'nomic-embed-text',
    rerankModel: '',                 // пусто — используется лексический реранк
    timeout: 180000,
    numCtx: 8192,
    temperature: 0.7,
    enabled: true
  },
  prompts: DEFAULT_PROMPTS,
  search: { maxContextChunks: 10, maxChunkChars: 1000, webResults: 10, wikiResults: 10 },
  ocr: { autoOnUpload: true, maxFileMB: 2 },
  stylePresets: {
    default:  { label: 'По умолчанию', systemSuffix: '' },
    formal:   { label: 'Формально',    systemSuffix: '\n\nСТИЛЬ: Отвечай строго, формально, деловым языком. Без сленга, эмодзи и шуток.' },
    friendly: { label: 'Дружелюбно',   systemSuffix: '\n\nСТИЛЬ: Отвечай тепло, дружелюбно, по-человечески. Уместные эмодзи допустимы.' },
    terse:    { label: 'Тезисно',      systemSuffix: '\n\nСТИЛЬ: Только ключевые пункты, без вступлений и заключений. Максимальная сжатость.' },
    code:     { label: 'Для кода',     systemSuffix: '\n\nСТИЛЬ: Технически точен. Примеры — кодом. Комментарии — только по делу.' },
  },
  whisper: appCfg.whisper || { binaryPath:'', modelPath:'', language:'ru' },  // [FIX] из env
  tts:     appCfg.tts     || { url:'', voice:'default', format:'wav' },       // [FIX] из env
};

/* ---------- SHA-1 ---------- */
function getFileSha1(absPath) {
  try {
    const buf = fs.readFileSync(absPath);
    return crypto.createHash('sha1').update(buf).digest('hex');
  } catch { return null; }
}

function loadAiConfig() {
  if (!fs.existsSync(AI_CONFIG_FILE)) {
    fs.writeFileSync(AI_CONFIG_FILE, JSON.stringify(DEFAULT_CONFIG, null, 2));
    return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  }
  try {
    const c = JSON.parse(fs.readFileSync(AI_CONFIG_FILE, 'utf8'));
    c.ollama       = { ...DEFAULT_CONFIG.ollama,       ...(c.ollama       || {}) };
    c.prompts      = { ...DEFAULT_PROMPTS,             ...(c.prompts      || {}) };
    c.search       = { ...DEFAULT_CONFIG.search,       ...(c.search       || {}) };
    c.ocr          = { ...DEFAULT_CONFIG.ocr,          ...(c.ocr          || {}) };
    c.stylePresets = { ...DEFAULT_CONFIG.stylePresets, ...(c.stylePresets || {}) };
    c.whisper      = { ...DEFAULT_CONFIG.whisper,      ...(c.whisper      || {}) };
    c.tts          = { ...DEFAULT_CONFIG.tts,          ...(c.tts          || {}) };
    return c;
  } catch { return JSON.parse(JSON.stringify(DEFAULT_CONFIG)); }
}
function saveAiConfig(c) { fs.writeFileSync(AI_CONFIG_FILE, JSON.stringify(c, null, 2)); }

function applySubs(t, s) {
  return String(t || '').replace(/\{(\w+)\}/g, (_, k) => s[k] !== undefined ? String(s[k]) : `{${k}}`);
}
function buildSubs(c = {}) {
  const n = new Date();
  return {
    username: c.username || 'гость', role: c.role || 'member',
    project: c.project || '—', file: c.file || '—',
    date: n.toLocaleDateString('ru-RU'),
    time: n.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
    lang: c.lang || 'ru', mode: c.mode || 'chat',
    context: c.context || '', query: c.query || '',
    history: c.history || '', text: c.text || '',
    prompt: c.prompt || '', template: c.template || '',
    attachments: c.attachments || '(нет)'
  };
}

/* ---------- HTTP ---------- */
function httpRequest(url, { method='GET', headers={}, body=null } = {}, timeoutMs=60000) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request({
      hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search, method, headers, timeout: timeoutMs
    }, res => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return httpRequest(res.headers.location, { method, headers, body }, timeoutMs).then(resolve, reject);
      }
      const ch = [];
      res.on('data', d => ch.push(d));
      res.on('end', () => {
        const txt = Buffer.concat(ch).toString('utf8');
        if (res.statusCode >= 200 && res.statusCode < 300) resolve(txt);
        else reject(new Error(`HTTP ${res.statusCode}: ${txt.slice(0,300)}`));
      });
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

function httpRequestBinary(url, { method='POST', headers={}, body=null } = {}, timeoutMs=60000) {
  return new Promise((resolve, reject) => {
    const u = new URL(url);
    const lib = u.protocol === 'https:' ? https : http;
    const req = lib.request({
      hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname + u.search, method, headers, timeout: timeoutMs
    }, res => {
      const ch = [];
      res.on('data', d => ch.push(d));
      res.on('end', () => {
        const buf = Buffer.concat(ch);
        if (res.statusCode >= 200 && res.statusCode < 300) resolve({ buffer: buf, headers: res.headers });
        else reject(new Error(`HTTP ${res.statusCode}: ${buf.toString('utf8').slice(0,300)}`));
      });
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', reject);
    if (body) req.write(body);
    req.end();
  });
}

/* ---------- Ollama ---------- */
function isTransientConnError(e) {
  const s = String((e && (e.code || e.message)) || '');
  return /socket hang up|ECONNRESET|ECONNREFUSED|EPIPE|ETIMEDOUT|timeout/i.test(s);
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function ollamaChat(messages, opts = {}) {
  const cfg = loadAiConfig();
  const body = JSON.stringify({
    model: opts.model || cfg.ollama.chatModel,
    messages, stream: false,
    options: {
      temperature: opts.temperature ?? cfg.ollama.temperature,
      num_ctx:     opts.numCtx     ?? cfg.ollama.numCtx,
      ...(opts.numPredict ? { num_predict: opts.numPredict } : {}),
    }
  });
  const send = () => httpRequest(cfg.ollama.url.replace(/\/$/, '') + '/api/chat',
    { method:'POST', headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}, body },
    opts.timeout || cfg.ollama.timeout);
  let raw;
  try {
    raw = await send();
  } catch (e) {
    // Один повтор: Ollama могла перезапустить runner и сбросить соединение.
    if (!isTransientConnError(e)) throw e;
    await sleep(800);
    raw = await send();
  }
  try { return stripSpecialTokens(JSON.parse(raw).message?.content || ''); } catch { return ''; }
}

async function ollamaChatStream(messages, opts, onChunk) {
  let emitted = false;
  const wrapped = (piece) => { emitted = true; try { onChunk(piece); } catch {} };
  try {
    return await ollamaChatStreamOnce(messages, opts, wrapped);
  } catch (e) {
    if (!emitted && isTransientConnError(e)) {
      await sleep(800);
      return ollamaChatStreamOnce(messages, opts, onChunk);
    }
    throw e;
  }
}

async function ollamaChatStreamOnce(messages, opts, onChunk) {
  const cfg = loadAiConfig();
  const body = JSON.stringify({
    model: opts.model || cfg.ollama.chatModel,
    messages, stream: true,
    options: {
      temperature: opts.temperature ?? cfg.ollama.temperature,
      num_ctx:     opts.numCtx     ?? cfg.ollama.numCtx,
      ...(opts.numPredict ? { num_predict: opts.numPredict } : {}),
    }
  });
  const url = cfg.ollama.url.replace(/\/$/, '') + '/api/chat';
  const u = new URL(url);
  const lib = u.protocol === 'https:' ? https : http;
  const timeoutMs = opts.timeout || cfg.ollama.timeout || 180000;
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn, value) => { if (settled) return; settled = true; clearTimeout(timer); fn(value); };
    const timer = setTimeout(() => {
      try { req.destroy(new Error('Ollama не ответила за ' + Math.round(timeoutMs / 1000) + ' с')); } catch {}
    }, timeoutMs);
    if (timer.unref) timer.unref();

    const req = lib.request({
      hostname: u.hostname, port: u.port || (u.protocol === 'https:' ? 443 : 80),
      path: u.pathname, method:'POST',
      headers: {'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}
    }, res => {
      if (res.statusCode !== 200) {
        let b = ''; res.on('data', d => b += d);
        res.on('end', () => finish(reject, new Error(`HTTP ${res.statusCode}: ${b.slice(0,300)}`)));
        return;
      }
      let buf = '', full = '';
      res.on('data', chunk => {
        buf += chunk.toString('utf8');
        let i;
        while ((i = buf.indexOf('\n')) !== -1) {
          const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
          if (!line) continue;
          try {
            const j = JSON.parse(line);
            const piece = j.message?.content || '';
            if (piece) { full += piece; try { onChunk(piece); } catch {} }
            if (j.done) { finish(resolve, full); return; }
          } catch {}
        }
      });
      res.on('end', () => finish(resolve, full));
      res.on('error', e => finish(reject, e));
    });
    // Сервер может попросить отменить запрос (клиент закрыл вкладку).
    if (typeof opts.onRequest === 'function') { try { opts.onRequest(req); } catch {} }
    req.on('error', e => finish(reject, e));
    req.write(body);
    req.end();
  });
}

async function ollamaEmbed(text) {
  const cfg = loadAiConfig();
  const body = JSON.stringify({ model: cfg.ollama.embedModel, prompt: String(text || '').slice(0, 8000) });
  try {
    const raw = await httpRequest(cfg.ollama.url.replace(/\/$/, '') + '/api/embeddings',
      { method:'POST', headers:{'Content-Type':'application/json','Content-Length':Buffer.byteLength(body)}, body }, 60000);
    return JSON.parse(raw).embedding || null;
  } catch { return null; }
}

async function ollamaPing() {
  const cfg = loadAiConfig();
  try {
    const raw = await httpRequest(cfg.ollama.url.replace(/\/$/, '') + '/api/tags', {}, 4000);
    const j = JSON.parse(raw);
    return { ok: true, models: (j.models || []).map(m => m.name) };
  } catch (e) { return { ok: false, error: e.message }; }
}

/* ================== Embeddings / Semantic RAG ================== */
const EMBED_CACHE_FILE = path.join(DATA_DIR, 'embeddings.json');
const EMBED_MAX_ITEMS = 50000;

function loadEmbedCache() {
  try {
    const c = JSON.parse(fs.readFileSync(EMBED_CACHE_FILE, 'utf8'));
    if (!c || typeof c !== 'object') return { model: '', items: {} };
    if (!c.items || typeof c.items !== 'object') c.items = {};
    return c;
  } catch { return { model: '', items: {} }; }
}
function saveEmbedCache(d) {
  try {
    if (!d.items) d.items = {};
    const keys = Object.keys(d.items);
    if (keys.length > EMBED_MAX_ITEMS) {
      const keep = keys.slice(-EMBED_MAX_ITEMS);
      const ni = {};
      for (const k of keep) ni[k] = d.items[k];
      d.items = ni;
    }
    fs.writeFileSync(EMBED_CACHE_FILE, JSON.stringify(d));
  } catch {}
}
function chunkSha(text) {
  return crypto.createHash('sha1').update(String(text)).digest('hex');
}
function cosineSim(a, b) {
  if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length || !a.length) return 0;
  let dot = 0, na = 0, nb = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i];
    na  += a[i] * a[i];
    nb  += b[i] * b[i];
  }
  const d = Math.sqrt(na) * Math.sqrt(nb);
  return d > 0 ? dot / d : 0;
}
function ensureCacheModel() {
  const cfg = loadAiConfig();
  const want = cfg.ollama.embedModel || '';
  const cache = loadEmbedCache();
  if (cache.model !== want) {
    cache.model = want;
    cache.items = {};
    saveEmbedCache(cache);
  }
  return cache;
}
function invalidateFileCache(projectId, rel) {
  try {
    const cache = loadEmbedCache();
    let removed = 0;
    for (const [sha, item] of Object.entries(cache.items)) {
      if (item.p === projectId && item.f === rel) { delete cache.items[sha]; removed++; }
    }
    if (removed) saveEmbedCache(cache);
    return removed;
  } catch { return 0; }
}

async function indexFile(projectId, absPath, rel) {
  const cfg = loadAiConfig();
  if (!cfg.ollama.embedModel) return { indexed: 0 };

  const ext = (rel.split('.').pop() || '').toLowerCase();
  let st; try { st = fs.statSync(absPath); } catch { return { indexed: 0 }; }
  if (!st.isFile()) return { indexed: 0 };

  let text = '';
  if (extractor.isImgExt(ext)) {
    if (st.size > 30 * 1024 * 1024) return { indexed: 0 };
    const hash = getFileSha1(absPath);
    if (!hash) return { indexed: 0 };
    const ocr = loadOcrCache();
    const item = ocr.items && ocr.items[hash];
    if (!item) return { indexed: 0 };
    text = [item.description, item.text].filter(Boolean).join('\n');
  } else if (extractor.isExtractable(ext)) {
    if (st.size > 20 * 1024 * 1024) return { indexed: 0 };
    try { text = await extractor.extractText(absPath, ext); }
    catch (e) { return { indexed: 0, error: e.message }; }
  } else {
    return { indexed: 0 };
  }

  if (!text || !text.trim()) return { indexed: 0 };

  const cache = ensureCacheModel();
  const maxChars = cfg.search.maxChunkChars;
  let indexed = 0;
  for (const ch of splitChunks(text, maxChars)) {
    const sha = chunkSha(ch);
    if (cache.items[sha]) continue;
    const vec = await ollamaEmbed(ch);
    if (!vec || !vec.length) continue;
    cache.items[sha] = { v: vec, t: ch, p: projectId, f: rel };
    indexed++;
    if (indexed % 10 === 0) saveEmbedCache(cache);
  }
  saveEmbedCache(cache);
  return { indexed };
}

async function indexProjects(projects, opts = {}) {
  const cfg = loadAiConfig();
  if (!cfg.ollama.embedModel) return { ok: false, error: 'embedModel не задан в конфиге' };

  const maxPerRun = opts.maxChunksPerRun || Infinity;
  const cache = ensureCacheModel();
  const maxChars = cfg.search.maxChunkChars;
  const ocrCache = loadOcrCache();
  let indexed = 0, skipped = 0, errors = 0;

  const walkAll = (root) => {
    const files = [];
    const rec = (dir, depth) => {
      if (depth > 8) return;
      let es; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
      for (const e of es) {
        if (e.name.startsWith('.')) continue;
        const full = path.join(dir, e.name);
        if (e.isDirectory()) { rec(full, depth + 1); continue; }
        if (!e.isFile()) continue;
        const ext = e.name.split('.').pop().toLowerCase();
        if (extractor.isExtractable(ext) || extractor.isImgExt(ext)) files.push({ full, ext });
      }
    };
    rec(root, 0);
    return files;
  };

  for (const pr of projects) {
    if (!fs.existsSync(pr.root)) continue;
    const files = walkAll(pr.root);

    for (const { full, ext } of files) {
      let text = '';
      try {
        if (extractor.isImgExt(ext)) {
          const hash = getFileSha1(full);
          if (!hash) continue;
          const item = ocrCache.items && ocrCache.items[hash];
          if (!item) continue;
          text = [item.description, item.text].filter(Boolean).join('\n');
        } else {
          const st = fs.statSync(full);
          if (st.size > 20 * 1024 * 1024) continue;
          text = await extractor.extractText(full, ext);
        }
      } catch { errors++; continue; }
      if (!text || !text.trim()) continue;

      const rel = path.relative(pr.root, full).split(path.sep).join('/');
      for (const ch of splitChunks(text, maxChars)) {
        const sha = chunkSha(ch);
        if (cache.items[sha]) { skipped++; continue; }
        if (indexed >= maxPerRun) {
          saveEmbedCache(cache);
          return { ok: true, indexed, skipped, errors,
                   total: Object.keys(cache.items).length,
                   model: cache.model, capped: true };
        }
        try {
          const vec = await ollamaEmbed(ch);
          if (!vec || !vec.length) { errors++; continue; }
          cache.items[sha] = { v: vec, t: ch, p: pr.id, f: rel };
          indexed++;
          if (indexed % 25 === 0) saveEmbedCache(cache);
        } catch { errors++; }
      }
    }
    saveEmbedCache(cache);
  }
  return { ok: true, indexed, skipped, errors,
           total: Object.keys(cache.items).length, model: cache.model };
}

async function semanticSearch(projects, query, opts = {}) {
  const cfg = loadAiConfig();
  if (!cfg.ollama.embedModel) return [];
  const cache = ensureCacheModel();
  if (!Object.keys(cache.items).length) return [];

  const qvec = await ollamaEmbed(query);
  if (!qvec || !qvec.length) return [];

  const minScore = opts.minScore ?? 0.35;
  const allowed = new Set(projects.map(p => p.id));
  const scored = [];

  for (const item of Object.values(cache.items)) {
    if (!allowed.has(item.p)) continue;
    const sc = cosineSim(qvec, item.v);
    if (sc < minScore) continue;
    scored.push({ item, sc });
  }
  scored.sort((a, b) => b.sc - a.sc);

  const out = [];
  for (const { item, sc } of scored.slice(0, opts.maxChunks || 20)) {
    const pr = projects.find(p => p.id === item.p);
    if (!pr) continue;
    out.push({
      projectId: item.p,
      projectName: pr.name,
      path: item.f,
      kind: 'text',
      content: item.t,
      score: sc,
      semantic: true,
    });
  }
  return out;
}

/* ================== Reranker ================== */
async function rerankCandidates(query, candidates, opts = {}) {
  if (!candidates.length) return candidates;
  const topN = opts.topN || 12;
  const maxCand = opts.maxCandidates || 40;
  const subset = candidates.slice(0, maxCand);

  const cfg = loadAiConfig();
  if (cfg.ollama.rerankModel) {
    try { return await rerankWithModel(query, subset, topN); }
    catch { /* fallback */ }
  }
  return lexicalRerank(query, subset, topN);
}

async function rerankWithModel(query, candidates, topN) {
  const cfg = loadAiConfig();
  const blocks = candidates.map((c, i) => `[${i+1}] ${String(c.content || '').slice(0, 500)}`).join('\n\n');
  const prompt = `Оцени релевантность каждого фрагмента к запросу по шкале 0-10 (10 — идеально).
Верни ТОЛЬКО JSON-массив чисел без пояснений, по одному на каждый фрагмент, в том же порядке.

ЗАПРОС: ${query}

ФРАГМЕНТЫ:
${blocks}`;

  const raw = await ollamaChat(
    [{ role: 'user', content: prompt }],
    { model: cfg.ollama.rerankModel, temperature: 0, timeout: 60000, numCtx: 4096 }
  );
  const m = raw.match(/\[\s*[\d.,\s]+\]/);
  if (!m) throw new Error('rerank: no json array');
  const scores = JSON.parse(m[0]);

  const scored = candidates.map((c, i) => ({
    ...c,
    rerankScore: Math.max(0, Math.min(10, Number(scores[i]) || 0)) / 10,
    _origScore: c.score || 0,
  }));

  const maxRr = Math.max(...scored.map(x => x.rerankScore), 0.001);
  const maxOrig = Math.max(...scored.map(x => x._origScore), 0.001);
  for (const x of scored) {
    x.score = 0.65 * (x.rerankScore / maxRr) + 0.35 * (x._origScore / maxOrig);
    delete x._origScore;
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, topN);
}

function lexicalRerank(query, candidates, topN) {
  const terms = extractTerms(query);
  if (!terms.length) return candidates.slice(0, topN);

  const df = new Map();
  for (const c of candidates) {
    const low = String(c.content || '').toLowerCase();
    const seen = new Set();
    for (const t of terms) if (low.includes(t)) seen.add(t);
    for (const t of seen) df.set(t, (df.get(t) || 0) + 1);
  }
  const N = candidates.length || 1;

  const scored = candidates.map(c => {
    const low = String(c.content || '').toLowerCase();
    let s = 0;
    for (const t of terms) {
      if (!low.includes(t)) continue;
      const idf = Math.log((N + 1) / ((df.get(t) || 0) + 1)) + 1;
      s += idf;
    }
    const lenNorm = Math.sqrt(Math.max(1, c.content.length / 500));
    return { ...c, rerankScore: s / lenNorm, _origScore: c.score || 0 };
  });

  const maxRr = Math.max(...scored.map(x => x.rerankScore), 0.001);
  const maxOrig = Math.max(...scored.map(x => x._origScore), 0.001);
  for (const x of scored) {
    x.score = 0.6 * (x.rerankScore / maxRr) + 0.4 * (x._origScore / maxOrig);
    delete x._origScore;
  }
  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, topN);
}

/* ---------- OCR cache ---------- */
function loadOcrCache() {
  try { return JSON.parse(fs.readFileSync(OCR_CACHE_FILE, 'utf8')); }
  catch { return { items: {} }; }
}
function saveOcrCache(d) {
  try { fs.writeFileSync(OCR_CACHE_FILE, JSON.stringify(d, null, 2)); } catch {}
}

/* ---------- Vision / OCR ---------- */
function cleanBase64(b64) {
  return String(b64 || '').replace(/^data:image\/[a-z]+;base64,/i, '');
}
function isVisionModel(name) {
  const n = String(name || '').toLowerCase();
  if (!n) return false;
  // qwen2.5vl / qwen25vl / qwen3-vl и т.п.; llava, pixtral, minicpm-v, moondream...
  if (/qwen[\d.]*[\s._-]?vl/.test(n)) return true;
  return n.includes('vision') || n.includes('llava') || n.includes('qwen-vl') ||
         n.includes('qwen2-vl') || n.includes('qwen2.5-vl') || n.includes('gemma3') ||
         n.includes('gemma4') || n.includes('minicpm-v') || n.includes('bakllava') ||
         n.includes('moondream') || n.includes('pixtral') || n.includes('internvl') ||
         n.includes('granite-vision');
}

// Кэш проверки возможностей модели через Ollama /api/show (capabilities: ["vision", ...]).
const visionCapsCache = new Map();
async function isVisionModelAsync(name) {
  const key = String(name || '');
  if (!key) return false;
  if (isVisionModel(key)) return true;
  if (visionCapsCache.has(key)) return visionCapsCache.get(key);
  let ok = false;
  try {
    const cfg = loadAiConfig();
    const raw = await httpRequest(cfg.ollama.url.replace(/\/$/, '') + '/api/show', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: key }),
    }, 8000);
    const info = JSON.parse(raw);
    ok = Array.isArray(info.capabilities) && info.capabilities.includes('vision');
  } catch {}
  visionCapsCache.set(key, ok);
  return ok;
}

// Служебные токены шаблонов Ollama (<|img|>, <|file|...|>, <|endoftext|> …)
// не должны попадать в ответ пользователю.
function stripSpecialTokens(text) {
  return String(text || '')
    .replace(/<\|[^<>]{0,100}?\|>/g, '')
    .replace(/[ \t]{2,}/g, ' ')
    .trim();
}

// Чистим результат генерации документа: без ACTION-блоков, markdown-обёрток и
// вступительных фраз модели («Создаю файл…», «Вот документ…»).
function cleanGeneratedMarkdown(raw) {
  let t = stripSpecialTokens(raw);
  const hadAction = /<{2,3}\s*ACTION\s*>{2,3}/i.test(t);
  t = t.replace(/<{2,3}\s*ACTION\s*>{2,3}[\s\S]*?(?:<{2,3}\s*END\s*ACTION\s*>{2,3}|$)/gi, '').trim();
  t = t.replace(/^```(?:markdown|md|html)?\s*\n?/i, '').replace(/\n?```\s*$/, '').trim();
  const h = t.search(/^#\s+/m);
  if (h > 0 && h < 800) t = t.slice(h).trim();
  // Если модель выдала только служебное вступление + ACTION, документа нет.
  else if (hadAction && h < 0) t = '';
  return t;
}

async function ocrImage(absPath) {
  const cfg = loadAiConfig();
  const st = fs.statSync(absPath);
  if (st.size > cfg.ocr.maxFileMB * 1024 * 1024) return { text:'', boxes:[], error:'too big' };
  const b64 = cleanBase64(fs.readFileSync(absPath).toString('base64'));
  const prompt = applySubs(cfg.prompts.ocr, buildSubs({ mode:'ocr' }));
  const model = cfg.ollama.visionModel;
  if (!(await isVisionModelAsync(model))) {
    return { text:'', boxes:[], error: `Модель "${model}" не является vision-моделью (в админке → Darcus выберите vision-модель)` };
  }
  try {
    const t = await ollamaChat([{ role:'user', content: prompt, images:[b64] }], { model, temperature: 0.1 });
    if (/не могу|изображение не|не предоставлен|не вижу картинк|не получено|не удалось получить|не предоставили/i.test(t || '')) {
      return { text:'', boxes:[], error:'vision-model-rejected: ' + (t || '').slice(0, 120) };
    }
    return { text: stripSpecialTokens(t).slice(0, 8000), boxes: [] };
  } catch (e) { return { text:'', boxes:[], error:e.message }; }
}

// Vision-модели часто возвращают JSON с реальными переводами строк внутри строк
// (невалидный JSON) или в ```json-обёртке. Разбираем максимально терпимо.
function parseVisionJson(raw) {
  let s = stripSpecialTokens(raw)
    .replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/, '').trim();
  let body = '';
  const m = s.match(/\{[\s\S]*\}/);
  if (m) body = m[0];
  else {
    // Ответ мог обрезаться по лимиту токенов — берём всё после первой `{`.
    const start = s.indexOf('{');
    if (start < 0) return null;
    body = s.slice(start);
  }
  try { return JSON.parse(body); } catch {}
  const unescape = t => String(t || '')
    .replace(/\\n/g, '\n').replace(/\\r/g, '\r').replace(/\\t/g, '\t')
    .replace(/\\"/g, '"').replace(/\\\\/g, '\\');
  const field = (name) => {
    let mm = body.match(new RegExp('"' + name + '"\\s*:\\s*"([\\s\\S]*?)"\\s*,', 'i'));
    if (!mm) mm = body.match(new RegExp('"' + name + '"\\s*:\\s*"([\\s\\S]*?)"\\s*}', 'i'));
    if (!mm) mm = body.match(new RegExp('"' + name + '"\\s*:\\s*"([\\s\\S]*)$', 'i'));
    return unescape(mm ? mm[1] : '').replace(/\\+$/, '').trim();
  };
  const description = field('description');
  const text = field('text');
  if (!description && !text) return null;
  return { description, text, boxes: [] };
}

async function describeImage(absPath) {
  const cfg = loadAiConfig();
  const st = fs.statSync(absPath);
  if (st.size > cfg.ocr.maxFileMB * 1024 * 1024) return { description:'', text:'', boxes:[], error:'too big' };
  const b64 = cleanBase64(fs.readFileSync(absPath).toString('base64'));
  const prompt = applySubs(cfg.prompts.vision, buildSubs({ mode:'vision' }));
  const model = cfg.ollama.visionModel;
  if (!(await isVisionModelAsync(model))) {
    return { description:'', text:'', boxes:[], error: `Модель "${model}" не является vision-моделью (в админке → Darcus выберите vision-модель)` };
  }
  try {
    const raw = stripSpecialTokens(await ollamaChat([{ role:'user', content: prompt, images:[b64] }], { model, temperature: 0.1 }));
    const j = parseVisionJson(raw);
    if (j) {
      let description = String(j.description || '').slice(0, 1000);
      // Некоторые модели возвращают текст шаблона вместо описания — не показываем его.
      if (/краткое описание|весь распознанный текст|строго json|пример/i.test(description)) description = '';
      return {
        description,
        text: String(j.text || '').slice(0, 8000),
        boxes: Array.isArray(j.boxes) ? j.boxes.slice(0, 60) : []
      };
    }
    return { description: raw.slice(0, 800), text:'', boxes:[] };
  } catch (e) { return { description:'', text:'', boxes:[], error:e.message }; }
}

/* ================== RAG ================== */
const TEXT_EXT = extractor.TEXT_EXT;
const IMG_EXT  = extractor.IMG_EXT;
const EXTRACTABLE_EXT = extractor.EXTRACTABLE_EXT;

function extractTerms(q) {
  return String(q || '').toLowerCase().replace(/[^\wа-яё\s-]/gi, ' ')
    .split(/\s+/).filter(w => w.length >= 3).slice(0, 12);
}
function scoreChunk(text, terms) {
  if (!terms.length) return 0;
  const low = String(text).toLowerCase();
  let s = 0;
  for (const t of terms) {
    let i = 0, c;
    while ((c = low.indexOf(t, i)) !== -1) { s++; i = c + t.length; if (s > 100) return s; }
  }
  return s;
}
function splitChunks(text, max) {
  const out = []; let cur = '';
  for (const ln of String(text).split('\n')) {
    if ((cur + '\n' + ln).length > max) { if (cur) out.push(cur); cur = ln; }
    else cur = cur ? cur + '\n' + ln : ln;
  }
  if (cur) out.push(cur);
  return out;
}
function walkProject(root, cb, depth = 0) {
  if (depth > 8) return;
  let es; try { es = fs.readdirSync(root, { withFileTypes: true }); } catch { return; }
  for (const e of es) {
    if (e.name.startsWith('.')) continue;
    const full = path.join(root, e.name);
    if (e.isDirectory()) walkProject(full, cb, depth + 1);
    else if (e.isFile()) {
      const ext = e.name.split('.').pop().toLowerCase();
      cb(full, ext);
    }
  }
}
async function keywordSearch(projects, query, opts = {}) {
  const cfg = loadAiConfig();
  const maxChunks = opts.maxChunks || cfg.search.maxContextChunks;
  const maxChars  = opts.maxChars  || cfg.search.maxChunkChars;
  const terms = extractTerms(query);
  if (!terms.length) return [];
  const cache = loadOcrCache();
  const results = [];

  for (const pr of projects) {
    if (!fs.existsSync(pr.root)) continue;
    const files = [];
    walkProject(pr.root, (abs, ext) => files.push({ abs, ext }));

    for (const { abs, ext } of files) {
      const rel = path.relative(pr.root, abs).split(path.sep).join('/');

      if (IMG_EXT.includes(ext)) {
        const hash = getFileSha1(abs);
        if (!hash) continue;
        const item = cache.items[hash];
        if (!item) continue;
        const content = [item.description, item.text].filter(Boolean).join('\n');
        const sc = scoreChunk(content, terms);
        if (sc > 0) {
          results.push({ projectId: pr.id, projectName: pr.name,
            path: rel, kind: 'image', content, score: sc * 2 });
        }
        continue;
      }

      if (!extractor.isExtractable(ext)) continue;
      let text = '';
      try {
        const st = fs.statSync(abs);
        if (st.size > 20 * 1024 * 1024) continue;
        text = extractor.isTextExt(ext)
          ? fs.readFileSync(abs, 'utf8')
          : await extractor.extractText(abs, ext);
      } catch { continue; }
      if (!text) continue;

      for (const ch of splitChunks(text, maxChars)) {
        const sc = scoreChunk(ch, terms);
        if (sc > 0) {
          results.push({ projectId: pr.id, projectName: pr.name,
            path: rel, kind: 'text', content: ch, score: sc });
        }
      }
    }
  }
  results.sort((a, b) => b.score - a.score);
  return results.slice(0, maxChunks);
}

async function ragSearch(projects, query, opts = {}) {
  const cfg = loadAiConfig();
  const maxChunks = opts.maxChunks || cfg.search.maxContextChunks;
  const maxChars  = opts.maxChars  || cfg.search.maxChunkChars;

  const kw = await keywordSearch(projects, query, { maxChars, maxChunks: maxChunks * 3 });

  const useEmbed = opts.useEmbed !== false && !!cfg.ollama.embedModel;
  let sem = [];
  if (useEmbed) {
    try { sem = await semanticSearch(projects, query, { maxChunks: maxChunks * 3 }); }
    catch { sem = []; }
  }
  if (!sem.length) return kw.slice(0, maxChunks);

  const map = new Map();
  const maxKw  = kw.reduce((m, r)  => Math.max(m, r.score), 1) || 1;
  const maxSem = sem.reduce((m, r) => Math.max(m, r.score), 1) || 1;

  for (const r of kw) {
    const k = r.projectId + '::' + r.path + '::' + chunkSha(r.content);
    map.set(k, { ...r, kwScore: r.score / maxKw, semScore: 0 });
  }
  for (const r of sem) {
    const k = r.projectId + '::' + r.path + '::' + chunkSha(r.content);
    const ex = map.get(k);
    if (ex) ex.semScore = r.score / maxSem;
    else    map.set(k, { ...r, kwScore: 0, semScore: r.score / maxSem });
  }

  const out = [...map.values()].map(r => {
    r.score = r.kwScore * 0.4 + r.semScore * 0.6;
    return r;
  });
  out.sort((a, b) => b.score - a.score);

  const preRerank = out.slice(0, Math.max(maxChunks * 3, 30));
  let finalList = preRerank.slice(0, maxChunks);
  if (opts.useRerank !== false && preRerank.length > maxChunks) {
    try { finalList = await rerankCandidates(query, preRerank, { topN: maxChunks }); }
    catch { finalList = preRerank.slice(0, maxChunks); }
  }
  return finalList;
}

/* ================== Web search ================== */
async function ddgSearch(q, limit) {
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`;
  try {
    const html = await httpRequest(url, { headers: { 'User-Agent': 'Mozilla/5.0 (compatible; DarkArmyDossier/1.0)' } }, 9000);
    const out = [];
    const re = /<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g;
    let m;
    while ((m = re.exec(html)) && out.length < limit) {
      let href = m[1];
      if (href.startsWith('//duckduckgo.com/l/?uddg=')) {
        try { href = decodeURIComponent(href.split('uddg=')[1].split('&')[0]); } catch {}
      }
      out.push({ title: m[2].replace(/<[^>]+>/g, '').trim(), url: href });
    }
    return out;
  } catch { return []; }
}
async function wikiSearch(q, limit) {
  try {
    const raw = await httpRequest(
      `https://ru.wikipedia.org/w/api.php?action=opensearch&search=${encodeURIComponent(q)}&limit=${limit}&format=json&origin=*`,
      {}, 8000);
    const [, titles, descs, urls] = JSON.parse(raw);
    return (titles || []).map((t, i) => ({ title: t, snippet: descs[i], url: urls[i] }));
  } catch { return []; }
}

/* ================== Darcus ================== */
/* Правила качества и интерактивные предложения после ответа. */
const QUALITY_PROMPT = `

=== КАЧЕСТВО ОТВЕТА ===
- Сначала суть, потом детали; никакой воды и повторов.
- Если вопрос про файлы проекта — опирайся на контекст и указывай пути.
- Длинный ответ разбивай на логические части; не обрывай мысль на полуслове.
  Если ответ не помещается, дай законченную первую часть и предложи продолжить.
- Не выдумывай факты; если данных нет — честно скажи и предложи, что проверить.
- Соблюдай Markdown: заголовки, списки, таблицы только когда это реально улучшает читаемость.`;

const FILE_PROMPT = `

=== СОЗДАВАЙ ФАЙЛЫ, А НЕ ТЕКСТ В ЧАТЕ ===
Если пользователь просит реферат, статью, документ, план, инструкцию, большой
список, код или другой объёмный текст — ты ОБЯЗАН создать/изменить файл через
ACTION-блок. В обычном тексте ответа напиши только короткое подтверждение
(1–2 предложения) и путь к файлу. НЕ дублируй содержимое файла в чате.
Для БОЛЬШИХ документов (реферат, документация, статья, инструкция) используй
специальный тип, чтобы содержимое не обрезалось:
<<<ACTION>>>
{"type":"generate_doc","path":"docs/guide.md","prompt":"подробное описание того, что должно быть в документе"}
<<<END ACTION>>>
Для небольших файлов можно использовать "type":"create" с полем content.
Поле path всегда указывай ОТНОСИТЕЛЬНО КОРНЯ текущего проекта, без имени
проекта и без папки проекта. Если пользователь просит показать/объяснить/обсудить —
можно ответить текстом без ACTION.

Дополнительные полезные действия (тоже ACTION-блоком):
- открыть файл в интерфейсе: {"type":"open","path":"docs/guide.md"}
- создать задачу проекта: {"type":"task","text":"...","assignee":"логин","priority":"normal","due":"2026-12-31"}
- открыть поиск с запросом: {"type":"search","query":"..."}
Используй их, когда это уместно: «открой файл», «поставь задачу», «найди в проекте».`;

async function darcusAsk({ user, projects, projectId, history, query, attachments, editingFile, stylePreset, voiceMode, visionContext, projectTasks, onChunk, onRequest }) {
  const cfg = loadAiConfig();
  const project = projects.find(p => p.id === projectId);
  const subs = buildSubs({
    username: user.username, role: user.role,
    project: project?.name || '', mode: 'chat',
    file: editingFile || '—',
  });

  const rag = await ragSearch(projects, query, {});
  const ragText = rag.map((r, i) => `[${i+1}] ${r.projectName} / ${r.path}\n${r.content.slice(0, 700)}`).join('\n\n---\n\n');

  let attachText = '';
  const imageParts = [];
  const atts = Array.isArray(attachments) ? attachments.slice(0, 6) : [];
  for (const a of atts) {
    try {
      if (!a || !a.data) continue;
      if (a.kind === 'image') {
        const b64 = cleanBase64(a.data);
        const approxBytes = Math.floor(b64.length * 0.75);
        if (approxBytes > 12 * 1024 * 1024) { attachText += `- "${a.name}" — слишком большое изображение\n`; continue; }
        imageParts.push(b64);
        attachText += `- "${a.name}" — изображение (проанализируй ниже)\n`;
      } else {
        const buf = Buffer.from(a.data, 'base64');
        let text = buf.toString('utf8');
        if (text.length > 30000) text = text.slice(0, 30000) + '\n…(обрезано)';
        attachText += `<<<FILE name="${a.name}" mime="${a.mime || 'text/plain'}">>>\n`;
        attachText += text;
        attachText += `\n<<<END FILE name="${a.name}">>>\n`;
      }
    } catch (e) { attachText += `- "${a?.name || '?'}" — ошибка чтения\n`; }
  }

  const [ddg, wiki] = await Promise.all([
    cfg.search.webResults > 0 ? ddgSearch(query, cfg.search.webResults) : Promise.resolve([]),
    cfg.search.wikiResults > 0 ? wikiSearch(query, cfg.search.wikiResults) : Promise.resolve([])
  ]);
  let webText = '';
  if (ddg.length)  webText += 'Интернет:\n' + ddg.map((w,i)=>`${i+1}. ${w.title} — ${w.url}`).join('\n') + '\n\n';
  if (wiki.length) webText += 'Википедия:\n' + wiki.map((w,i)=>`${i+1}. ${w.title} — ${w.snippet||''} (${w.url})`).join('\n');

  const ctxParts = [];
  // Встроенная RAG-база инструкций по самому приложению (ai-knowledge/*.md).
  const instructionHits = searchInstructions(query, 3);
  if (instructionHits.length) {
    ctxParts.push('### ИНСТРУКЦИИ ПО DARKARMY DOSSIER (актуально; используй для вопросов о приложении):\n' +
      instructionHits.map(c => `[${c.file} · ${c.heading}]\n${c.text}`).join('\n\n---\n\n'));
  }
  if (Array.isArray(projectTasks) && projectTasks.length) {
    ctxParts.push('### Задачи текущего проекта:\n' + projectTasks.map(t =>
      `- [${t.status === 'done' ? 'готово' : t.status === 'doing' ? 'в работе' : 'к выполнению'}] ${t.text}` +
      (t.assignee ? ` · исполнитель: ${t.assignee}` : '') +
      (t.priority && t.priority !== 'normal' ? ` · приоритет: ${t.priority}` : '') +
      (t.due ? ` · срок: ${t.due}` : '')).join('\n'));
  }
  if (visionContext) ctxParts.push('### Ранее приложенное изображение (полное описание/OCR):\n' + String(visionContext).slice(0, 5000));
  if (ragText) ctxParts.push('### Из файлов проектов:\n' + ragText);
  if (webText) ctxParts.push('### Из внешних источников:\n' + webText);
  if (editingFile) {
    ctxParts.unshift('### Пользователь сейчас редактирует файл:\n`' + editingFile + '`\n(Если он просит «измени», «допиши», «создай» — учитывай это как контекст)');
  }
  const context = ctxParts.join('\n\n');

  const histText = (history || []).slice(-8)
    .map(m => `${m.role === 'user' ? 'Пользователь' : 'Darcus'}: ${m.content}`).join('\n');

  // [FIX] Применяем stylePreset к системному промпту
  const preset = (cfg.stylePresets && stylePreset) ? cfg.stylePresets[stylePreset] : null;
  let sysPrompt = applySubs(cfg.prompts.system, subs);
  if (preset && preset.systemSuffix) sysPrompt += preset.systemSuffix;
  sysPrompt += QUALITY_PROMPT + FILE_PROMPT;
  if (instructionHits.length) {
    sysPrompt += '\n\n=== ИНСТРУКЦИИ DARKARMY DOSSIER ===\n' +
      'Если вопрос касается возможностей, интерфейса, кнопок, Darcus, офлайн-режима, микрофона, ' +
      'совместной работы, установки или деплоя — опирайся на раздел «ИНСТРУКЦИИ ПО DARKARMY DOSSIER» ' +
      'в контексте. Не выдумывай функции, которых там нет. Если инструкция не покрывает вопрос — ' +
      'честно скажи и предложи проверить соответствующий экран/файл.';
  }
  if (voiceMode) {
    sysPrompt += '\n\n=== ГОЛОСОВОЙ РЕЖИМ (КРИТИЧНО) ===\n' +
      'Ответ будет озвучен вслух. КАТЕГОРИЧЕСКИ отвечай кратко: максимум 3 предложения ' +
      '(до ~400 символов), простой разговорный текст. ' +
      'Без списков, таблиц, блоков кода, ссылок, эмодзи и длинных перечислений. ' +
      'Сначала сразу ответ по сути, без вступлений. ' +
      'Если нужно выполнить действие с файлом — одно короткое предложение и ACTION-блок в конце.';
  }

  /* Бюджет промпта: раньше история (до 64k) + вложения (до 180k) + RAG
     давали до ~250k символов при num_ctx 8192 — Ollama молча обрезала начало,
     то есть выбрасывала system-промпт с правилами. */
  const maxPromptChars = Math.max(6000, (cfg.ollama.numCtx || 8192) * 2);
  let budget = maxPromptChars - sysPrompt.length - String(query || '').length - 1200;
  if (budget < 2000) budget = 2000;
  const trimPart = (text, share, label) => {
    const limit = Math.max(0, Math.floor(budget * share));
    const t = String(text || '');
    const out = t.length > limit ? t.slice(0, limit) + `\n…(${label} сокращено из-за лимита контекста)` : t;
    budget -= out.length;
    return out;
  };
  const contextTrimmed = trimPart(context, 0.45, 'контекст');
  const historyTrimmed = trimPart(histText, 0.25, 'история');
  const attachmentsTrimmed = trimPart(attachText || '(нет)', 0.30, 'вложения');

  // Для запросов с изображениями используем КОМПАКТНЫЙ промпт без отдельной
  // system-роли: qwen2.5vl (и некоторые другие vision-модели) при длинном
  // system-промпте теряют изображение и отвечают "<|img|>" / «картинка не
  // предоставлена». Короткий user-промпт с картинками работает стабильно.
  let messages;
  let modelOpts;
  if (imageParts.length) {
    const visionModel = cfg.ollama.visionModel;
    if (!(await isVisionModelAsync(visionModel))) {
      throw new Error(`Vision-модель "${visionModel}" не поддерживает изображения. Выберите vision-модель в админке → Darcus.`);
    }
    const visionPrompt = applySubs(cfg.prompts.vision_chat || DEFAULT_PROMPTS.vision_chat, {
      ...subs, query, attachments: attachmentsTrimmed,
      // Компактный контекст: qwen2.5vl теряет изображение при длинном промпте.
      context: contextTrimmed.slice(0, 900), history: historyTrimmed.slice(0, 600),
    }) + (voiceMode ? '\n\nГОЛОСОВОЙ РЕЖИМ: ответ озвучивается — отвечай кратко, 1–3 предложениями, без списков и Markdown.' : '')
      + FILE_PROMPT;
    messages = [{ role: 'user', content: visionPrompt, images: imageParts }];
    modelOpts = { model: visionModel, temperature: 0.2 };
  } else {
    messages = [
      { role: 'system', content: sysPrompt },
      { role: 'user',   content: applySubs(cfg.prompts.chat, {
          ...subs, context: contextTrimmed, query, history: historyTrimmed,
          attachments: attachmentsTrimmed
        }) }
    ];
    modelOpts = {};
  }
  if (typeof onRequest === 'function') modelOpts.onRequest = onRequest;

  let answer = await ollamaChatStream(messages, modelOpts, voiceMode ? (() => {}) : onChunk);
  answer = stripSpecialTokens(answer);
  if (voiceMode) {
    // Голосовой режим: не даём модели «разговориться». Если в ответе есть
    // ACTION (создание файла), не обрезаем его; иначе оставляем 1–3 фразы
    // и убираем Markdown-разметку, которую бессмысленно читать вслух.
    if (!/<<<\s*ACTION\s*>>>/i.test(answer)) {
      let plain = answer
        .replace(/^#{1,6}\s+/gm, '')
        .replace(/^\s*[-*•]\s+/gm, '')
        .replace(/\*\*([^*]+)\*\*/g, '$1')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/[*_>~|]+/g, ' ')
        .replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu, ' ')
        .replace(/[ \t]+/g, ' ')
        .trim();
      const parts = plain.split(/(?<=[.!?…])\s+/).filter(Boolean);
      let short = parts.slice(0, 3).join(' ').trim();
      if (!short) short = plain.slice(0, 420).trim();
      if (short.length > 420) {
        const cut = short.slice(0, 420);
        const p = Math.max(cut.lastIndexOf('. '), cut.lastIndexOf('! '), cut.lastIndexOf('? '));
        short = cut.slice(0, p > 150 ? p + 1 : 420).trim();
      }
      answer = short;
    }
    if (typeof onChunk === 'function' && answer) { try { onChunk(answer); } catch {} }
  }
  if (!answer.trim()) throw new Error('Модель вернула пустой ответ. Попробуйте ещё раз или выберите другую модель.');
  // Оценка занятого контекста: примерно 3.2 символа на токен для русского.
  const promptChars = messages.reduce((n, m) =>
    n + String(m.content || '').length + (Array.isArray(m.images) ? m.images.length * 6000 : 0), 0);
  const limit = Number(cfg.ollama && cfg.ollama.numCtx) || 8192;
  const used = Math.ceil((promptChars + answer.length) / 3.2);
  const percent = Math.max(0, Math.min(100, Math.round(used / limit * 100)));
  return {
    answer,
    context: { used, limit, percent, remaining: Math.max(0, limit - used), nearLimit: percent >= 90 },
    sources: rag.slice(0, 8).map(r => ({ projectId: r.projectId, projectName: r.projectName, path: r.path, kind: r.kind })),
    web: ddg.slice(0, 4).map(w => ({ title: w.title, url: w.url })),
    wiki: wiki.slice(0, 2).map(w => ({ title: w.title, url: w.url }))
  };
}

/* ================== Document summarization ================== */
async function summarizeContent(text, opts = {}) {
  const cfg = loadAiConfig();
  // [FIX] ограничиваем вход под num_ctx (примерно 2.5 символа на токен)
  const numCtx = cfg.ollama.numCtx || 8192;
  const maxChars = opts.maxChars || Math.min(40000, Math.floor(numCtx * 2.5));
  const t = String(text || '').slice(0, maxChars);
  if (!t.trim()) return { tldr: '', points: [], entities: [] };

  const prompt = applySubs(cfg.prompts.summarize, buildSubs({ mode: 'summarize', text: t }));
  const raw = await ollamaChat([
    { role: 'system', content: 'Ты — анализатор. Отвечай ТОЛЬКО JSON-объектом. Никаких пояснений.' },
    { role: 'user',   content: prompt },
  ], { temperature: 0.1, numCtx });

  // [FIX] ищем JSON: сначала в ```json```, потом просто {...}
  let jsonText = '';
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) jsonText = fenced[1].trim();
  else {
    const m = raw.match(/\{[\s\S]*\}/);
    jsonText = m ? m[0] : '';
  }

  if (!jsonText) {
    // модель не выдала JSON — отдаём сырой текст в tldr, чтобы UI не был пустым
    const clean = raw.trim().slice(0, 800);
    return { tldr: clean, points: [], entities: [], _raw: true };
  }
  try {
    const j = JSON.parse(jsonText);
    return {
      tldr:     String(j.tldr || '').slice(0, 1200),
      points:   Array.isArray(j.points)   ? j.points.slice(0, 15).map(String)   : [],
      entities: Array.isArray(j.entities) ? j.entities.slice(0, 40).map(String) : [],
    };
  } catch {
    return { tldr: raw.trim().slice(0, 800), points: [], entities: [], _raw: true };
  }
}

/* ================== TTS: подготовка русского текста ==================
   Silero RU не произносит латиницу и иногда пропускает цифры/аббревиатуры.
   Переводим бренды, аббревиатуры и любые латинские слова в кириллицу,
   числа — в слова. */
const TTS_WORDS = [
  [/\bDarcus[\s-]*Intelligence\b/gi, 'Даркус Интеллидженс'],
  [/\bDark[\s-]*Army[\s-]*Dossier\b/gi, 'Дарк Арми Досье'],
  [/\bDarkArmy\b/gi, 'Дарк Арми'],
  [/\bDark[\s-]*Army\b/gi, 'Дарк Арми'],
  [/\bDarcus\b/gi, 'Даркус'],
  [/\bDossier\b/gi, 'Досье'],
  [/\bSilero\b/gi, 'Силеро'],
  [/\bOllama\b/gi, 'Оллама'],
  [/\bWhisper\b/gi, 'Виспер'],
  [/\bQwen\b/gi, 'Квен'],
  [/\bGitHub\b/gi, 'Гитхаб'],
  [/\bTelegram\b/gi, 'Телеграм'],
  [/\bWindows\b/gi, 'Виндоус'],
  [/\bChrome\b/gi, 'Хром'],
  [/\bLinux\b/gi, 'Линукс'],
  [/\bMarkdown\b/gi, 'Маркдаун'],
  [/\bREADME\b/gi, 'Ридми'],
  [/\bOCR\b/g, 'о цэ эр'],
  [/\bSTT\b/g, 'эс тэ тэ'],
  [/\bTTS\b/g, 'тэ тэ эс'],
  [/\bAPI\b/g, 'а пи ай'],
  [/\bAI\b/g, 'эй ай'],
  [/\bURL\b/g, 'у эр эл'],
  [/\bHTTPS\b/g, 'эйч ти ти пи эс'],
  [/\bHTTP\b/g, 'эйч ти ти пи'],
  [/\bJSON\b/g, 'джейсон'],
  [/\bSQL\b/g, 'эс кью эл'],
  [/\bPDF\b/g, 'пэ дэ эф'],
  [/\bPNG\b/g, 'пэ эн дж'],
  [/\bJPEG\b/g, 'джей пег'],
  [/\bJPG\b/g, 'джей пег'],
  [/\bGIF\b/g, 'гиф'],
  [/\bCSV\b/g, 'си эс ви'],
  [/\bXML\b/g, 'икс эм эл'],
  [/\bHTML\b/g, 'эйч ти эм эл'],
  [/\bCSS\b/g, 'си эс эс'],
  [/\bJS\b/g, 'джей эс'],
  [/\bGPU\b/g, 'джи пи ю'],
  [/\bCPU\b/g, 'си пи ю'],
  [/\bRAM\b/g, 'рам'],
  [/\bIP\b/g, 'ай пи'],
  [/\bID\b/g, 'ай ди'],
  [/\bVPS\b/g, 'вэ пэ эс'],
  [/\bCtrl\b/gi, 'контрол'],
  [/\bShift\b/gi, 'шифт'],
  [/\bAlt\b/gi, 'альт'],
  [/\bEnter\b/gi, 'энтер'],
  [/\bEscape\b/gi, 'эскейп'],
  [/\bTab\b/gi, 'таб'],
];
const RU_DIGITS = ['ноль','один','два','три','четыре','пять','шесть','семь','восемь','девять'];
const RU_TEENS = ['десять','одиннадцать','двенадцать','тринадцать','четырнадцать','пятнадцать','шестнадцать','семнадцать','восемнадцать','девятнадцать'];
const RU_TENS = ['', '', 'двадцать','тридцать','сорок','пятьдесят','шестьдесят','семьдесят','восемьдесят','девяносто'];
const RU_HUNDREDS = ['', 'сто','двести','триста','четыреста','пятьсот','шестьсот','семьсот','восемьсот','девятьсот'];
function ruNumber(n) {
  n = Math.floor(Math.abs(Number(n)));
  if (!Number.isFinite(n) || n > 9999) return String(n);
  if (n < 10) return RU_DIGITS[n];
  if (n < 20) return RU_TEENS[n - 10];
  if (n < 100) return (RU_TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + RU_DIGITS[n % 10] : '')).trim();
  if (n < 1000) return (RU_HUNDREDS[Math.floor(n / 100)] + (n % 100 ? ' ' + ruNumber(n % 100) : '')).trim();
  const th = Math.floor(n / 1000), rest = n % 1000;
  const thWord = th === 1 ? 'одна тысяча' : th === 2 ? 'две тысячи' : th < 5 ? ruNumber(th) + ' тысячи' : ruNumber(th) + ' тысяч';
  return (thWord + (rest ? ' ' + ruNumber(rest) : '')).trim();
}
const LATIN_RU = { a:'а', b:'б', c:'к', d:'д', e:'е', f:'ф', g:'г', h:'х', i:'и', j:'дж', k:'к', l:'л', m:'м', n:'н', o:'о', p:'п', q:'к', r:'р', s:'с', t:'т', u:'у', v:'в', w:'в', x:'кс', y:'и', z:'з' };
function translitWord(w) {
  const lower = w.toLowerCase();
  if (lower.length === 1) {
    return { a:'а', b:'бэ', c:'цэ', d:'дэ', e:'е', f:'эф', g:'жэ', h:'эйч', i:'и', j:'джей', k:'ка', l:'эл', m:'эм', n:'эн', o:'о', p:'пэ', q:'кью', r:'эр', s:'эс', t:'тэ', u:'у', v:'вэ', w:'дабл ю', x:'икс', y:'игрек', z:'зэт' }[lower] || lower;
  }
  return lower
    .replace(/sh/g, 'ш').replace(/ch/g, 'ч').replace(/zh/g, 'ж').replace(/th/g, 'т')
    .replace(/ph/g, 'ф').replace(/ck/g, 'к').replace(/oo/g, 'у').replace(/ee/g, 'и')
    .replace(/[a-z]/g, ch => LATIN_RU[ch] || ch);
}
function prepareTtsText(input) {
  let t = String(input || '');
  // HTML-плашки действий и любые теги в речь не попадают.
  t = t.replace(/<div[^>]*darcus-action-done[^>]*>[\s\S]*?<\/div>/gi, ' ')
       .replace(/<[^>]+>/g, ' ')
       .replace(/<<<\s*SUGGESTIONS?\s*>>>[\s\S]*?(?:<<<\s*END\s*SUGGESTIONS?\s*>>>|$)/gi, ' ')
       .replace(/✅\s*Darcus\s+[^.\n]*?(?=[.!?\n]|$)/gi, ' ');
  t = t.replace(/https?:\/\/\S+/gi, ' ').replace(/```[\s\S]*?```/g, ' ').replace(/`[^`]*`/g, ' ');
  // Ctrl+S и подобные сочетания — до замены «+» на «и»
  const KEY_RU = { ctrl: 'контрол', shift: 'шифт', alt: 'альт', cmd: 'команд' };
  t = t.replace(/\b(Ctrl|Shift|Alt|Cmd)\s*\+\s*([A-Za-z0-9])\b/gi,
    (m, key, ch) => (KEY_RU[key.toLowerCase()] || key) + ' ' + translitWord(ch));
  // бренды/аббревиатуры — до транслитерации файлов
  for (const [re, ru] of TTS_WORDS) t = t.replace(re, ru);
  // файлы: README.md -> ридми точка эм дэ (для оставшейся латиницы)
  t = t.replace(/\b([A-Za-z][A-Za-z0-9_-]{0,40})\.(md|txt|png|jpe?g|pdf|docx?|xlsx?|json|csv|html|css|js|exe|zip)\b/gi,
    (m, name, ext) => translitWord(name) + ' точка ' + translitWord(ext));
  // расширения у уже кириллических имён: Ридми.md -> ридми точка эм дэ
  t = t.replace(/\.(md|txt|png|jpe?g|pdf|docx?|xlsx?|json|csv|html|css|js|exe|zip)\b/gi,
    (m, ext) => ' точка ' + translitWord(ext));
  // даты 25.11.2026 / 2026-11-25 — до разбора версий с точкой
  t = t.replace(/\b(\d{1,2})\.(\d{1,2})\.(\d{4})\b/g, (m, d, mo, y) => ruNumber(d) + ' ' + ruNumber(mo) + ' ' + ruNumber(y));
  t = t.replace(/\b(\d{4})-(\d{2})-(\d{2})\b/g, (m, y, mo, d) => ruNumber(y) + ' ' + ruNumber(mo) + ' ' + ruNumber(d));
  // версии/числа с точкой: 5.6 -> пять точка шесть
  t = t.replace(/(\d+)[.,](\d+)/g, (m, a, b) => ruNumber(a) + ' точка ' + ruNumber(b));
  t = t.replace(/(\d+)\s*%/g, (m, n) => ruNumber(n) + ' процентов');
  t = t.replace(/\s*[&+]\s*/g, ' и ').replace(/\s*=\s*/g, ' равно ');
  t = t.replace(/[A-Za-z][A-Za-z0-9_-]*/g, translitWord);
  t = t.replace(/\d+/g, n => ruNumber(n));
  t = t.replace(/[\u{1F000}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}\u{200D}]/gu, ' ');
  t = t.replace(/[•·▪▫◦‣]/g, ' ').replace(/\s+/g, ' ');
  return t.trim();
}

/* ================== TTS proxy ================== */
async function ttsSynthesize(text, opts = {}) {
  const cfg = loadAiConfig();
  const t = cfg.tts || {};
  if (!t.url) throw new Error('TTS сервис не настроен (TTS_URL)');
  const spoken = prepareTtsText(text).slice(0, 5000);
  const body = JSON.stringify({
    text: spoken || String(text || '').slice(0, 5000),
    voice: opts.voice || t.voice || 'default',
    format: opts.format || t.format || 'wav',
    language: opts.language || 'ru',
  });
  const { buffer, headers } = await httpRequestBinary(t.url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    body,
  }, 90000);
  return { buffer, contentType: headers['content-type'] || `audio/${t.format || 'wav'}` };
}

/* ================== Whisper STT ================== */
function transcribeWithPython(buffer, w, language) {
  const child = require('child_process');
  const tmp = path.join(DATA_DIR, 'stt-' + crypto.randomBytes(8).toString('hex') + '.webm');
  fs.writeFileSync(tmp, buffer);
  const python = w.pythonPath || process.env.PYTHON_BIN || 'python';
  const script = path.join(__dirname, 'scripts', 'faster_whisper_stt.py');
  const model = w.model || w.modelPath || 'base';
  const lang = language || w.language || 'ru';
  return new Promise((resolve, reject) => {
    const p = child.spawn(python, [script, String(model), tmp, lang], {
      windowsHide: true,
      env: {
        ...process.env,
        PYTHONIOENCODING: 'utf-8',
        PYTHONUTF8: '1',
        STT_HOTWORDS: w.hotwords || 'реферат, документ, проект, файл, папка, изображение, распознавание, контекст, Darcus, Dossier, DarkArmy, Silero, Whisper, администратор, подписка, приглашение, телеметрия',
        STT_INITIAL_PROMPT: w.initialPrompt || 'Пользователь надиктовывает запрос или текст документа для проекта DarkArmy Dossier. В речи часто встречаются слова: реферат, документ, проект, файл, Darcus, распознавание, контекст.',
      },
    });
    let stdout = '', stderr = '';
    const timer = setTimeout(() => { try { p.kill(); } catch {} reject(new Error('faster-whisper timeout')); }, 180000);
    p.stdout.on('data', d => stdout += d.toString('utf8'));
    p.stderr.on('data', d => stderr += d.toString('utf8'));
    p.on('error', e => { clearTimeout(timer); reject(e); });
    p.on('close', code => {
      clearTimeout(timer);
      try { fs.unlinkSync(tmp); } catch {}
      if (code !== 0) return reject(new Error('faster-whisper exit ' + code + ': ' + stderr.slice(-300)));
      const lines = stdout.trim().split(/\r?\n/).filter(Boolean);
      let parsed = null;
      for (let i = lines.length - 1; i >= 0 && !parsed; i--) { try { parsed = JSON.parse(lines[i]); } catch {} }
      if (!parsed) return reject(new Error('faster-whisper: пустой ответ'));
      if (parsed.error) return reject(new Error(parsed.error));
      resolve(String(parsed.text || '').trim());
    });
  });
}

async function transcribeAudio(buffer, opts = {}) {
  const cfg = loadAiConfig();
  const w = cfg.whisper || {};
  const usePython = (w.engine === 'faster-whisper') || w.binaryPath === 'faster-whisper';
  if (usePython && !(w.binaryPath && w.binaryPath !== 'faster-whisper')) {
    const text = await transcribeWithPython(buffer, w, opts.language);
    return { text };
  }
  if (!w.binaryPath || !w.modelPath)
    throw new Error('Whisper не настроен (WHISPER_BIN / WHISPER_MODEL)');

  const child = require('child_process');
  const tmp = path.join(DATA_DIR, 'stt-' + crypto.randomBytes(8).toString('hex') + '.webm');
  fs.writeFileSync(tmp, buffer);
  try {
    const lang = opts.language || w.language || 'ru';
    const out = await new Promise((resolve, reject) => {
      const args = ['-m', w.modelPath, '-f', tmp, '-l', lang, '--output-txt', '--no-timestamps'];
      const p = child.spawn(w.binaryPath, args);
      let stdout = '', stderr = '';
      p.stdout.on('data', d => stdout += d.toString('utf8'));
      p.stderr.on('data', d => stderr += d.toString('utf8'));
      p.on('close', code => {
        if (code !== 0) return reject(new Error('whisper exit ' + code + ': ' + stderr.slice(0, 300)));
        resolve(stdout);
      });
      p.on('error', reject);
    });
    return { text: String(out).trim() };
  } finally { try { fs.unlinkSync(tmp); } catch {} }
}

module.exports = {
  DEFAULT_CONFIG, DEFAULT_PROMPTS,
  loadAiConfig, saveAiConfig, applySubs, buildSubs,
  isVisionModel, isVisionModelAsync, stripSpecialTokens, cleanGeneratedMarkdown, parseVisionJson,
  ollamaChat, ollamaChatStream, ollamaEmbed, ollamaPing,
  ocrImage, describeImage,
  ragSearch, keywordSearch, semanticSearch,
  indexFile, indexProjects, invalidateFileCache,
  chunkSha, cosineSim,
  ddgSearch, wikiSearch,
  darcusAsk, loadOcrCache, saveOcrCache,
  getFileSha1,
  // RAG по встроенным инструкциям приложения
  searchInstructions, getKnowledgeStats,
  // [FIX] новые экспорты
  rerankCandidates, lexicalRerank,
  summarizeContent,
  ttsSynthesize,
  prepareTtsText,
  transcribeAudio,
  DATA_DIR, AI_CONFIG_FILE, EMBED_CACHE_FILE,
};